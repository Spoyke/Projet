/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32l4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32l4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define LED_MORSE_PORT GPIOA // à changer pour mettre les bon pins
#define LED_MORSE_PIN GPIO_PIN_5

#define BTN_MORSE_PORT GPIOC
#define BTN_MORSE_PIN GPIO_PIN_13

#define SEUIL 90 			// Seuil pour lequel on considère que le phototransistor n'est pas éclairé
#define PWM_MIN_VALUE 1000 	// Valeur minimal de la PWM (frquence du CCR)

uint8_t morse_btn_state = 0;
uint8_t motor_state = 0;

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim1;

void taskReadBtn() {
	morse_btn_state = HAL_GPIO_ReadPin(BTN_MORSE_PORT, BTN_MORSE_PIN) == 0 ? 1 : 0;
}

void taskBlinkLed() {
	static short sequenceStarted = 0;
	static int tickCount = 0; // 20 ticks = . et 60 ticks = -
	static int indexChar = 0;

	const char *morseCode = "- . - . . - - . . . - . . -";
	const uint8_t morseCodeLenght = 27;

	if(morse_btn_state == 1)
		sequenceStarted = 1;

	if(sequenceStarted == 0){
		HAL_GPIO_WritePin(LED_MORSE_PORT, LED_MORSE_PIN, GPIO_PIN_RESET);
		tickCount = 0;
		indexChar = 0;
	} else {
		tickCount++;
		char currentChar = morseCode[indexChar];

		GPIO_PinState pinState = (morseCode[indexChar] == ' ') ? GPIO_PIN_RESET : GPIO_PIN_SET;
		HAL_GPIO_WritePin(LED_MORSE_PORT, LED_MORSE_PIN, pinState);

		uint8_t endOfChar =
				(tickCount == 10 && (currentChar == '.' || currentChar == ' ')) ||
				(tickCount == 30 && currentChar == '-');

		if(endOfChar == 1){
			tickCount = 0;
			indexChar = (indexChar >= morseCodeLenght) ? 0 : indexChar+1;
		}

		if(indexChar >= morseCodeLenght){
			sequenceStarted = 0;
		}
	}
}

void taskReadLed() {
	short value = 0;
	HAL_ADC_Start(&hadc1); // On récupère et convertit la valeur de l'ADC en tension

	if(HAL_ADC_PollForConversion(&hadc1, 1) == HAL_OK){
		value  = HAL_ADC_GetValue(&hadc1) * 100 / 4095; // Pour avoir une valeur comprise entre 0 et 100
	}

	motor_state = value >= SEUIL ? 1 : 0;

	printf("%hd\r\n", value);
}

void taskControlMotor(){
	static short previous_state = 0;
	static short state_changed = 0;
	static int start_time = 0;

	if(previous_state != motor_state){
		state_changed = 1;
		start_time = HAL_GetTick();
		previous_state = motor_state;
	}

	if((state_changed == 1) && ((HAL_GetTick() - start_time) >= 1000)){
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, PWM_MIN_VALUE + PWM_MIN_VALUE * motor_state);
		state_changed = 0;
		start_time = 0;
	}
}
/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32L4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32l4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles TIM1 break interrupt and TIM15 global interrupt.
  */
void TIM1_BRK_TIM15_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 0 */

  /* USER CODE END TIM1_BRK_TIM15_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 1 */

  /* USER CODE END TIM1_BRK_TIM15_IRQn 1 */
}

/**
  * @brief This function handles TIM1 update interrupt and TIM16 global interrupt.
  */
void TIM1_UP_TIM16_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_UP_TIM16_IRQn 0 */

  /* USER CODE END TIM1_UP_TIM16_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  /* USER CODE BEGIN TIM1_UP_TIM16_IRQn 1 */

  /* USER CODE END TIM1_UP_TIM16_IRQn 1 */
}

/**
  * @brief This function handles TIM1 trigger and commutation interrupts.
  */
void TIM1_TRG_COM_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_TRG_COM_IRQn 0 */

  /* USER CODE END TIM1_TRG_COM_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  /* USER CODE BEGIN TIM1_TRG_COM_IRQn 1 */

  /* USER CODE END TIM1_TRG_COM_IRQn 1 */
}

/**
  * @brief This function handles TIM1 capture compare interrupt.
  */
void TIM1_CC_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_CC_IRQn 0 */

  /* USER CODE END TIM1_CC_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  /* USER CODE BEGIN TIM1_CC_IRQn 1 */

  /* USER CODE END TIM1_CC_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */
  static int taskNumber = 0;
  short nbTask = 4;

  taskNumber = (taskNumber + 1) % nbTask; // Permet de passer à la tâche suivante

  switch(taskNumber){
    case 0:
    	taskReadBtn();
    	break;
    case 1:
    	taskBlinkLed();
    	break;
    case 2:
    	taskReadLed();
    	break;
    case 3:
    	taskControlMotor();
    	break;
    default:
    	break;
      }
  /* USER CODE END TIM2_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
